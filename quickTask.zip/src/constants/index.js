import Logo from '../assets/images/Logo.png'
import Img_1 from '../assets/images/Rectangle33.png'
import Img_2 from '../assets/images/Rectangle34.png'
import Img_3 from '../assets/images/Rectangle40.png'
import Img_4 from '../assets/images/image2.png'
import Img_5 from '../assets/images/image3.png'
import Img_6 from '../assets/images/image4.png'
export const ROUTES =  {
    HOME:'/',
    ABOUT:'/about',
    BLOG : '/blog'  
}

export const IMAGES = {
Logo,
Img_1,
Img_2,
Img_3,
Img_4,
Img_5,
Img_6,
}