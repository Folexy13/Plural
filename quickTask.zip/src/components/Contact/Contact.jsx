import React, { useEffect } from "react";
import "./Contact.scss";
import Aos from "aos";
import "aos/dist/aos.css";
const Contact = () => {
  useEffect(() => {
    Aos.init({
      disable: window.innerWidth < 1251,
    });
  });
  return (
    <div className="contact" id="contact">
      <h1 style={{ color: "#fff" }}>Contact Us</h1>

      <div className="container">
        <div
          className="first"
          data-aos="slide-right"
          data-aos-offset="100"
          data-aos-easing="ease-out"
          data-aos-duration="1400"
        >
          <h3>Contact Us</h3>
          <div>
            <div className="sect">
              <i class="fa fa-map-marker" aria-hidden="true"></i>
              <span>Address</span>
            </div>
            <p>
              <span style={{ fontWeight: "700" }}>PLURAL HEALTH CARE LTD </span>
              Address: 56 Queens Avenue, Gedling, Nothingham, NG4 4EJ
            </p>
          </div>
          <div>
            <div className="sect">
              <i class="fa fa-paper-plane" aria-hidden="true"></i>
              <span>Email</span>
            </div>
            <p>Info@pluralhealthcareltd.co.uk</p>
          </div>
          <div>
            <div className="sect">
              <i class="fa fa-phone" aria-hidden="true"></i>
              <span>Phone</span>
            </div>
            <p>+44 7733718474</p>
          </div>
        </div>
        <div
          className="second"
          data-aos="slide-left"
          data-aos-offset="100"
          data-aos-easing="ease-out"
          data-aos-duration="1400"
        >
          <h3>Send us a message</h3>
          <form action="">
            <input type="text" placeholder="Name" required />
            <input type="email" placeholder="Email Address" required />
            <textarea
              name=""
              id=""
              cols="30"
              rows="10"
              required
              placeholder="Enter Your message..."
            />
            <button type="submit">Send Message</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contact;
