import React from "react";
import "./Button.scss";

const Button = ({ type }) => {
  if (type === "header") {
    return (
      <div className="btn">
        <button className="ctn2">Book an Appointment</button>
      </div>
    );
  }
  return (
    <div className="btn">
      <button className="cnt">Book an Appointment</button>
    </div>
  );
};

export default Button;
