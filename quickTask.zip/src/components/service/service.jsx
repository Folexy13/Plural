import Aos from "aos";
import React, { useEffect } from "react";
import {
  img1,
  img10,
  img4,
  img5,
  img6,
  img7,
  img8,
  img9,
} from "../../assets/images";
import "./service.scss";

function Service() {
  useEffect(() => {
    Aos.init({
      disable: window.innerWidth < 1251,
    });
  });
  return (
    <div className="service" id="service">
      <div className="service-main">
        <div className="service-main-wrapper">
          <div className="header">
            <h1>WHAT WE DO</h1>
          </div>
          <div className="service-flex">
            <div
              className="service-item1"
              data-aos="slide-right"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <img src={img4} alt="img.jpg" />
            </div>
            <div
              className="service-item"
              data-aos="slide-left"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <h1 className="header">Service</h1>
              <p>
                PLURAL HEALTH CARE LTD
                <span style={{ fontWeight: "400", marginLeft: "10px" }}>
                  is Domiciliary Care Company, Incorporated in England & Wales
                  as a Private limited Company, with a registration number of
                  13666845. We are registerered with the Care Quality Commission
                  (CQC) and a member of United Kingdom Home Care Association
                  (UKHCA). We provide services for our clients. We provide
                  comprehensive person-centred domiciliary care services to
                  children aged 13-18, Adults aged 18-65 & Adults aged 65 years
                  and beyond. We employ the services of support/care staff who
                  are experienced, have the requisite skills, ability and are
                  caring to provide a comprehensive range of domiciliary,
                  supported living and basic nursing observations where
                  necessary to our clients.
                </span>
              </p>
              <h6>
                We provide generic (core) and specialist service to include:
              </h6>
              <div className="list-item">
                <ul>
                  <li>Home care for specialist dementia service users</li>
                  <li>
                    Home care for Mental Health service users (Young to Adults)
                  </li>
                  <li>
                    Home care for Learning Disabilities and Special needs
                    service users
                  </li>
                  <li>Home care for End-of-life Care service users</li>
                  <li>
                    Home care for Brain Injury service users (non-medical Care)
                  </li>
                </ul>
              </div>
              <div className="button-container">
                <a href="/">View all service</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="service-second">
        <div className="service-second-container">
          <h1>Our Services</h1>
          <div className="second-flex">
            <div
              className="service-card"
              data-aos="slide-up"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <img src={img5} alt="img.jpg" />
              <h2>DEMENTIA FACILITIES</h2>
              <p>
                To make sure you receive the highest standards of care services
                that is person-centred/personalised.
              </p>
              <div className="card-link">
                <a href="/">Request Our Service</a>
              </div>
            </div>
            <div
              className="service-card"
              data-aos="slide-up"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <img src={img6} alt="img.jpg" />
              <h2>MENTAL HEALTH FACILITIES</h2>
              <p>Home care for Mental Health service users (Young to Adults)</p>
              <div className="card-link">
                <a href="/">Request Our Service</a>
              </div>
            </div>
            <div
              className="service-card"
              data-aos="slide-up"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <img src={img7} alt="img.jpg" />
              <h2>LEARNING FACILITIES</h2>
              <p>
                Home care for Learning Disabilities and Special needs service
                users
              </p>
              <div className="card-link">
                <a href="/">Request Our Service</a>
              </div>
            </div>
            <div
              className="service-card"
              data-aos="slide-up"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <img src={img8} alt="img.jpg" />
              <h2>OLD AGED FACILITIES</h2>
              <p>Home care for End-of-life Care service users</p>
              <div className="card-link">
                <a href="/">Request Our Service</a>
              </div>
            </div>
            <div
              className="service-card"
              data-aos="slide-up"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <img src={img9} alt="img.jpg" />
              <h2>BRAIN INJURY SERVICES</h2>
              <p>Home care for Brain Injury service users (non-medical Care)</p>
              <div className="card-link">
                <a href="/">Request Our Service</a>
              </div>
            </div>
            <div
              className="service-card"
              data-aos="slide-up"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <img src={img10} alt="img.jpg" />
              <h2>OTHER FACILITIES</h2>
              <p>Other generic (core) and specialist service.</p>
              <div className="card-link">
                <a href="/">Request Our Service</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Service;
