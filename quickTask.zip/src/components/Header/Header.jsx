// import { Fragment } from "react"
import { Link } from "react-router-dom";
import { IMAGES, ROUTES } from "../../constants";
import { Squash as Hamburger } from "hamburger-react";
import "./Header.scss";
import Button from "../Button/Button";

const Header = ({ click, show }) => {
  return (
    <div className="header">
      <nav>
        <ul>
          <Link to={ROUTES.HOME} className="logo">
            <img src={IMAGES.Logo} alt="" />
          </Link>

          <div className="menu-list">
            <li>
              <a href={"/#about"}>About Us</a>
            </li>
            <li>
              <a href="/#service">Services</a>
            </li>
            <li>
              <a href={"/#contact"}>Contact Us</a>
            </li>
            <li>
              <Button type={"header"} />
            </li>
          </div>
          <div className="hamburger__menu" onClick={click}>
            <Hamburger toggled={show} toggle={click} />
          </div>
        </ul>
      </nav>
    </div>
  );
};

export default Header;
