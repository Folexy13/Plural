import Aos from "aos";
import React, { useEffect } from "react";
import { AnimationOnScroll } from "react-animation-on-scroll";
import { img1 } from "../../assets/images";
import "aos/dist/aos.css";
import "./mission-card.scss";

function MissionCard() {
  useEffect(() => {
    Aos.init({
      disable: window.innerWidth < 1251,
    });
  });
  return (
    <div id="about" className="mission-card">
      <div className="main">
        <div className="main-container">
          <h1>ABOUT US</h1>
          <div className="mission-image-container">
            {/* <div className="mission-img">
              <img src={img1} alt="img.jpg" />
            </div> */}
            <div className="mission-title">
              <h2>Our Mission</h2>
            </div>
          </div>
        </div>
        {/* Stacked Cards */}
        <AnimationOnScroll animateIn="animate__tada" initiallyVisible>
          <div className="cards-container">
            <div
              className="card-item"
              data-aos="slide-top"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <h2>1.</h2>
              <p>
                To make sure you receive the highest standards of care services
                that is person-centred/personalised, meets your outcomes and
                enable you to achieve to maintain independent living.
              </p>
            </div>
            <div
              className="card-item"
              data-aos="slide-top"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <h2>2.</h2>
              <p>
                Ensure that you receive a safe, caring and responsive service,
                that our carers understand your needs and have the required
                knowledge and skills to support our clients.
              </p>
            </div>
            <div
              className="card-item"
              data-aos="slide-top"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <h2>3.</h2>
              <p>
                Maintain our responsibility to promote your privacy and dignity,
                respect your private space, provide help with intimate tasks
                discretely and ensure confidentiality of your personal
                information.
              </p>
            </div>
            <div
              className="card-item"
              data-aos="slide-top"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <h2>4.</h2>
              <p>
                That you continue to have the right to choose, for example, who
                looks after you, where you spend your time, who are your regular
                companions and what activities you are involved in. Having
                choice helps to promote your independence and relationships. We
                strongly feel that everyone has the right to be treated with
                dignity, respect, choice, to be cared for or supported.
              </p>
            </div>
          </div>
        </AnimationOnScroll>
      </div>
    </div>
  );
}

export default MissionCard;
