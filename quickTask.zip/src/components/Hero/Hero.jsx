import React from "react";
import { AnimationOnScroll } from "react-animation-on-scroll";
import { Button } from "..";
import "./Hero.scss";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from "react-responsive-carousel";
import { slider1, slider2, slider3 } from "../../assets/images";
const Hero = () => {
  return (
    <>
      <div className="hero-section">
        <AnimationOnScroll animateIn="animate__fadeInLeftBig" initiallyVisible>
          <div className="hero-title">
            <h1>Welcome to Plural Health Care Ltd</h1>
            <p>
              We believe in giving you the best medic care,you will never get
              anywhere
            </p>
            <Button />
          </div>
          <Carousel
            showIndicators={false}
            showArrows={false}
            infiniteLoop={true}
            autoPlay={true}
            interval={2000}
            showThumbs={false}
          >
            <div>
              <img src={slider1} alt="hh" />
            </div>
            <div>
              <img src={slider2} alt="hh" />
            </div>
            <div>
              <img src={slider3} alt="hh" />
            </div>
          </Carousel>
        </AnimationOnScroll>
      </div>
    </>
  );
};

export default Hero;
