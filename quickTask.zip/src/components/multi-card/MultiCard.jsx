import Aos from "aos";
import React, { useEffect } from "react";
import { img2, img3 } from "../../assets/images";
import "./multi-card.scss";
import "aos/dist/aos.css";
function MultiCard({ type }) {
  useEffect(() => {
    Aos.init({
      disable: window.innerWidth < 1251,
    });
  });
  if (type === "1" || !type) {
    return (
      <div className="multi-card">
        <div className="multi-container">
          <div>
            <h1>Aims</h1>
          </div>
          <div className="multi-flex">
            <div
              className="multi-item"
              data-aos="slide-right"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <p>
                We aim to provide the highest possible standards of care to all
                our clients. Our person-centred care approach is promoted to
                meet each of our service user’s unique and lifestyle needs. We
                aim to provide a homely environment where care and support is
                provided involving all our clients, their relatives, friends,
                medical professionals and other relevant personnel as
                appropriate to meet the essential needs of our clients.
              </p>
              <div className="list-group">
                <ul>
                  <li>
                    Offer skilled care to enable people supported by us to
                    achieve their optimum state of health and well-being.
                  </li>
                  <li>
                    Treat all people supported by us and all people who work
                    here with respect at all times.
                  </li>
                  <li>
                    Uphold the human and citizenship rights of all who work and
                    visit here and of all Service Users.
                  </li>
                  <li>
                    Respect and encourage the right of independence of all
                    Service Users.
                  </li>
                  <li>
                    Recognise the individual uniqueness of Service Users, staff
                    and visitors, and always treat them with dignity and
                    respect.
                  </li>
                  <li>
                    Recognise the individual need for personal fulfilment and
                    offer person-centred programs of meaningful activity to
                    satisfy that need of Service Users and staff.
                  </li>
                  <li>
                    Respect individual requirement for privacy at all times and
                    treat all information relating to individuals in a
                    confidential manner according to principles of GDPR
                  </li>
                </ul>
              </div>
            </div>
            <div
              className="multi-item"
              data-aos="slide-left"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <img src={img2} alt="img.jpg" />
            </div>
          </div>
        </div>
      </div>
    );
  } else if (type === "2") {
    return (
      <div className="multi-card">
        <div className="multi-container">
          <div className="right-header">
            <h1 className="multi-header">Objectives</h1>
            <h2>Our Objectives are to:</h2>
          </div>
          <div className="multi-flex">
            <div
              className="multi-item"
              data-aos="slide-right"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <img src={img3} alt="img.jpg" />
            </div>
            <div
              className="multi-item multi-right-item"
              data-aos="slide-left"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <div className="list-group">
                <ul>
                  <li>
                    Support Children, Elderly and Disabled Adults who needs full
                    or some assistance to meet their daily living needs which
                    they are unable to meet independently due to ill health,
                    physical disabilities, ageing or for recuperation.
                  </li>
                  <li>
                    Working and liaising with key stakeholders involved with our
                    clients to meet their total or holistic needs.
                  </li>
                  <li>
                    Educate Clients and their relatives about principles of
                    Direct Payment and Personal Budget, its ability to provide
                    flexibility, choice and control of how they meet their daily
                    needs. Enabling vulnerable adults to develop their
                    confidence and retaining control of the care and support
                    services they receive.
                  </li>
                  <li>
                    Assist our clients to develop their own individualised
                    support plan in full
                  </li>
                  <li>
                    consultation with family members, friends and care
                    professionals.
                  </li>
                  <li>
                    Support our service users to access support outside of PURAL
                    HEALTH CARE LTD. CARE SERVICES LIMITED.
                  </li>
                  <li>
                    Empower our clients by enabling them to choose their support
                    workers and involve our clients in the recruitment and
                    selection of support staff
                  </li>
                  <li>
                    Provide opportunities to choose from the range of
                    recreational, educational and employment opportunities that
                    are available in the community
                  </li>
                  <li>
                    To provide experienced and committed staff that have the
                    appropriate expertise and training to provide a holistic
                    service to adults with a range of complex needs
                  </li>
                  <li>
                    To promote a culture of continual learning within the staff
                    team and foster continual improvement in service delivery
                  </li>
                  <li>
                    To operate accordingly within the relevant legislative
                    framework and policy Guidance
                  </li>
                  <li>
                    To establish and maintain effective lines of communication
                    and joint working relationships with referring agencies and
                    relevant health and social care teams.
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  } else if (type === "3") {
    return (
      <div className="multi-card">
        <div className="multi-container">
          <div className="multi-flex">
            <div
              className="multi-item"
              data-aos="slide-right"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <div className="left-header">
                <h3>Ethos and Philosophy</h3>
                <h4>
                  PURAL HEALTH CARE LTD. CARE SERVICES LIMITED believes that
                  each client has the fundamental right to:
                </h4>
              </div>
              <div className="list-group">
                <ul>
                  <li>
                    Be regarded as an individual and given our special
                    attention;
                  </li>
                  <li>
                    Be cared for by people who are capable of understanding
                    their needs;
                  </li>
                  <li>
                    Be treated equally, and no less favourably than others;
                  </li>
                  <li>
                    Receive respect and understanding regarding their cultural,
                    religious and spiritual beliefs;
                  </li>
                  <li>
                    Be informed about all important decisions that affect them
                    if applicable, and to have a say;
                  </li>
                  <li>
                    Encourage our clients to complain about anything they feel
                    is unfair or unjust, and to have that complaint listened and
                    responded to;
                  </li>
                  <li>
                    Promoting independent living, working within your range of
                    abilities and competencies;
                  </li>
                  <li>
                    Ensuring that your confidential information is protected at
                    all times and only shared with others strictly in accordance
                    with our policy on confidentiality; Respecting and involving
                    people who use services
                  </li>
                  <li>
                    We see all our clients at the centre of our service. We
                    ensure that our clients and their representatives understand
                    our service information guide by using simple, easily
                    understood English language.
                  </li>
                  <li>
                    We work hard to promote independent living by supporting and
                    encouraging our clients to maintain and enhance their
                    abilities. We believe that our clients views are important
                    and should be listened and responded to.
                  </li>
                </ul>
              </div>
            </div>
            <div
              className="multi-item"
              data-aos="slide-left"
              data-aos-offset="100"
              data-aos-easing="ease-out"
              data-aos-duration="1400"
            >
              <img src={img2} alt="img.jpg" />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default MultiCard;
