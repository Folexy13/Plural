import React from "react";
import { Contact, Footer } from "../../components";
import "./styles.scss";
import "animate.css/animate.min.css";
import {
  Blog,
  Header,
  Hero,
  Blog2,
  MultiCard,
  MissionCard,
  Service,
} from "../../components";

function LandingPage() {
  return (
    <div className="landing">
      <Header />
      <Hero />
      <MissionCard />
      <MultiCard />
      <MultiCard type="2" />
      <MultiCard type="3" />
      <Service />
      {/* <Blog />
      <Blog2 /> */}
      <Contact />
      <Footer />
    </div>
  );
}

export default LandingPage;
