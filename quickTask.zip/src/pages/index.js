import LandingPage from "./LandingPage";
import Blog from "./Blog";

export { LandingPage, Blog as BlogPage };
